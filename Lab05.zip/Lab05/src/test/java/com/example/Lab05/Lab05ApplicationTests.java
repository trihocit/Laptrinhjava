package com.example.Lab05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
